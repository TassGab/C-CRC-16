﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace CRC_test
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("CRC-16 bit test program");
            Console.WriteLine("=======================");
            byte[] data={1,2,3,4,5,6,7,8,9};
            CRC16 crc=new CRC16();
            crc.clearCrc();
            UInt16 value = crc.XModemCrc(data, 0, 9);
            Console.WriteLine("input data {0}",Encoding.UTF8.GetString(data) );
            Console.WriteLine("crc=0x{0:X}", value);
            Console.ReadKey();
        }
    }
}
