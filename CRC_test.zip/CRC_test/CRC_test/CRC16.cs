﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRC_test
{
    class CRC16
    {
        UInt16 _msbMask;
        //Crc parameters
        UInt16 _mask;
        UInt16 _xorIn;
        UInt16 _xorOut;
        UInt16 _polynomial;
        bool _reflectIn; 

        bool _reflectOut; //
        //Crc value
        UInt16 _crc;
        byte reflect(UInt16 data, byte bits=16)
        {
        //-------------------------------------------------------
        // Reflects bit in a uint8_t
        //-------------------------------------------------------
	    UInt32 reflection = 0x00000000;
	    // Reflect the data about the center bit.
	    for (byte bit = 0; bit < bits; bit++)
	    {
	    	// If the LSB bit is set, set the reflection of it.
	    	if ((data & 0x01) != 0)
	    	{
	    		reflection |= (UInt32)(1 << ((bits - 1) - bit));
	    	}
        
	    	data = (byte)(data >> 1);
	    }
        
	    return (byte)reflection;
        }
        public void Crc16()
        {
            //Default to XModem parameters
            _reflectIn = false;
            _reflectOut = false;
            _polynomial = 0x1021;
            _xorIn = 0x0000;
            _xorOut = 0x0000;
            _msbMask = 0x8000;
            _mask = 0xFFFF;
        }
        public void Crc16(bool reflectIn, bool reflectOut, UInt16 polynomial, UInt16 xorIn, UInt16 xorOut, UInt16 msbMask, UInt16 mask)
        {
            _reflectIn = reflectIn;
            _reflectOut = reflectOut;
            _polynomial = polynomial;
            _xorIn = xorIn;
            _xorOut = xorOut;
            _msbMask = msbMask;
            _mask = mask;
        }
		public void clearCrc()
        {
            //---------------------------------------------------
            // Initialize crc calculation
            //---------------------------------------------------
            _crc = _xorIn;
        }
		void updateCrc(byte data)
        {
            //---------------------------------------------------
            // Update crc with new data
            //---------------------------------------------------
            if (!_reflectIn)
		    data = (byte) reflect(data, 8);

	        int j = 0x80;

	        while (j > 0)
	        {
	        	UInt16 bit = (UInt16)(_crc & _msbMask);
	        	
	        	_crc <<= 1;

	        	if ((data & j) != 0)
	        	{
	        		bit = (UInt16)(bit ^ _msbMask);
	        	}

	        	if (bit != 0)
	        	{
	        		_crc ^= _polynomial;
	        	}

	        	j >>= 1;
	        }
        }
		public UInt16 getCrc()
        {
            //---------------------------------------------------
            // Get final crc value
            //---------------------------------------------------

            if (!_reflectOut ) _crc = (UInt16)((reflect(_crc) ^ _xorOut) & _mask);
	        return _crc;
        }
        public UInt16 fastCrc(byte[] data, byte start, UInt16 length, bool reflectIn, bool reflectOut, UInt16 polynomial, UInt16 xorIn, UInt16 xorOut, UInt16 msbMask, UInt16 mask)
        {
            //---------------------------------------------------
// Calculate generic crc code on data array
// Examples of crc 16:
// Kermit: 		width=16 poly=0x1021 init=0x0000 refin=true  refout=true  xorout=0x0000 check=0x2189
// Modbus: 		width=16 poly=0x8005 init=0xffff refin=true  refout=true  xorout=0x0000 check=0x4b37
// XModem: 		width=16 poly=0x1021 init=0x0000 refin=false refout=false xorout=0x0000 check=0x31c3
// CCITT-False:	width=16 poly=0x1021 init=0xffff refin=false refout=false xorout=0x0000 check=0x29b1
//---------------------------------------------------

	UInt16 crc = xorIn;

	int j;
	byte c;
	UInt16 bit;

	if (length == 0) return crc;

	for (int i = start; i < (start + length); i++)
	{
		c = data[i];

		if (!reflectIn)
			c = (byte) reflect(c, 8);

		j = 0x80;

		while (j > 0)
		{
			bit = (UInt16)(crc & msbMask);
			crc <<= 1;

			if ((c & j) != 0)
			{
				bit = (UInt16)(bit ^ msbMask);
			}

			if (bit != 0)
			{
				crc ^= polynomial;
			}

			j >>= 1;
		}
	}

	if (!reflectOut )
		crc = (UInt16)((reflect(crc) ^ xorOut) & mask);

	return crc;
    }
        public UInt16 XModemCrc(byte[] data, byte start, UInt16 length)
{
    //  XModem parameters: poly=0x1021 init=0x0000 refin=false refout=false xorout=0x0000
    return fastCrc(data, start, length, false, false, 0x1021, 0x0000, 0x0000, 0x8000, 0xffff);
}
        

    }
}
